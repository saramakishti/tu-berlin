This is our SNET LaTeX Thesis template.


The version v1.9 - 2017-02-03 has been successfully tested on:

- Windows 7 + MikTex 2.9 + pdflatex
- Ubuntu 16.04LTS + TeX Live 2015 + pdflatex
- MacOS X + TeX Live 2016 + pdflatex
- www.overleaf.com
- www.sharelatex.com
- Ubuntu 17.04 + Tex Live 2016 + pdflatex

General hints:
- Compile using: pdflatex - biber - pdflatex


Known issues (may be addressed in future releases):
- warning: usage of package 'fancyHDR' together with 'KOMA-Script' is not recommended
- warning (MikTeX  only): bfx-bibtex.def Using fall-back BibTeX(8) backend:(biblatex) functionality may be reduced/unavailable
- warning: Underful \vbox badness...in 





